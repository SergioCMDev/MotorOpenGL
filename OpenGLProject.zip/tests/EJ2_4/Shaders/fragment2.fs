#version 330 core
out vec4 FragColor; 

void main() {
	    FragColor = vec4(0.4, 0.3, 0.2, 1.0);
}