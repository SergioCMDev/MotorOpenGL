#ifndef UTILS_H
#define UTILS_H
#include<iostream>
#include <string>

class Utils {

public:
	char* GetFinalPath(const char* pathInicial, const char* pathFinal);
};
#endif